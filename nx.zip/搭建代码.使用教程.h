#❗❗❗一定看下面说明，不看死妈❗❗❗
#注意，请按顺序输入搭建环境指令遇到让你填y或者n无脑选y即可❗❗❗
#如果环境未搭建成功极大概率无法使用工具请务必搭建完成❗❗❗
#因为以下安装工具代码中有几个工具是用来美化UI界面的代码所以有点多↓❗❗❗
#请放心这些工具没有任何病毒,锁机...而且占用内存很小不用担心❗❗❗
pkg update

pkg upgrade 

termux-setup-storage

pkg install git

pkg install python

pip install pyyaml

pip install tqdm

pkg install qemu-user-i386 -y

pkg install ruby

gem install lolcat

pkg install figlet

cd nx

chmod +x nx

chmod +x 美化配置.yaml

./nx
#使用说明↓
#:1.如何进入工具:打开termux输入每次进入termux输入: cd nx ./nx 即可进入工具（cd nx和./nx是俩代码❗）
#2.如何使用自动美化:第一步首先要把你要修改的皮肤代码放入到美化配置.yaml中，里面有格试一定要按照格式
#如何使用自动美化:第二步把你要修改的dat文件放入打包文件夹中，要可以自定义路径前提是要在yaml文件中输入你的文件路径（默认打包文件夹）
#如何使用自动美化:第三步打开工具启动自动美化即可
#3.如何解包:把要解包的pak文件放入pak文件夹中打开工具启动解包即可（解包好的dat文件在解包数据中）
#4.如何打包:把要打包的dat文件放入打包文件夹中，把原版pak放入pak文件夹中打开工具启动打包即可
#5.如何搜索美化dat:复制解包好的dat文件夹路径打开工具启动搜索美化dat输入路径即可