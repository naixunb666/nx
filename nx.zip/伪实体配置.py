source_folder = '解包数据/uexp'
output_folder = '打包/uexp'

target_markers = {
    '特征值1': '1879',
    '特征值2': '0c79'
}

search_values = [
    (403209, 403586),#红色运动上衣,小丑鱼

]