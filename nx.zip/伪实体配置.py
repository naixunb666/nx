source_folder = '解包数据/uexp'
output_folder = '打包/uexp'

target_markers = {
    '特征值1': '1879',
  # 非块自动美化特征值1: a9e1
    '特征值2': '0c79'
  # 非块自动美化特征值1: 9ee1    
}

search_values = [
    (403209, 403586),#红色运动上衣,小丑鱼

]